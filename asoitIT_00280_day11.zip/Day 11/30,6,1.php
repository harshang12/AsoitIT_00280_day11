
        <input type="text" id="fname"name="fname"> <br><br>
        <input type="text" id="fnamr"name="fname"><br><br>
        
        <input type="submit" value="Submit"><br><br>
        
        <input type="text" id="fname" name="fname"><br><br>