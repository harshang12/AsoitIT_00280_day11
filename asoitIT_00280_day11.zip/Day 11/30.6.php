<?php

echo"harshang";
$a=5;
$b=10;
$c=$a+$b;
echo $c;

?>